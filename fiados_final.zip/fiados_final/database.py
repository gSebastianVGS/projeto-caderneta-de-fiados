"""
database.py — Camada SQLite.
O fiados.db fica sempre ao lado do .exe ou do script.
"""
import sqlite3, os, sys
from datetime import datetime
from typing import List, Optional, Tuple


def get_db_path() -> str:
    if getattr(sys, "frozen", False):
        base = os.path.dirname(sys.executable)
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, "fiados.db")


class Database:
    def __init__(self):
        self.path = get_db_path()
        self._criar_tabelas()

    def _con(self) -> sqlite3.Connection:
        c = sqlite3.connect(self.path)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys = ON")
        c.execute("PRAGMA journal_mode = WAL")
        return c

    def _criar_tabelas(self):
        with self._con() as c:
            c.executescript("""
            CREATE TABLE IF NOT EXISTS clientes (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                nome      TEXT    NOT NULL UNIQUE COLLATE NOCASE,
                saldo     REAL    NOT NULL DEFAULT 0.0,
                criado_em TEXT    NOT NULL
            );
            CREATE TABLE IF NOT EXISTS transacoes (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                cliente_id  INTEGER NOT NULL REFERENCES clientes(id) ON DELETE CASCADE,
                tipo        TEXT    NOT NULL CHECK(tipo IN ('fiado','pagamento')),
                valor       REAL    NOT NULL CHECK(valor > 0),
                descricao   TEXT    NOT NULL DEFAULT '',
                criado_em   TEXT    NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_tc ON transacoes(cliente_id);
            """)

    def inserir_cliente(self, nome: str) -> Tuple[bool, str]:
        try:
            agora = datetime.now().isoformat(timespec="seconds")
            with self._con() as c:
                c.execute("INSERT INTO clientes (nome,saldo,criado_em) VALUES (?,0.0,?)",
                          (nome.strip(), agora))
            return True, "ok"
        except sqlite3.IntegrityError:
            return False, "Já existe um cliente com esse nome."
        except Exception as e:
            return False, str(e)

    def listar_clientes(self, busca="", ordem="nome") -> list:
        ordens = {
            "nome":    "nome COLLATE NOCASE ASC",
            "divida":  "saldo DESC, nome ASC",
            "recente": "criado_em DESC",
        }
        sql = ordens.get(ordem, "nome COLLATE NOCASE ASC")
        with self._con() as c:
            rows = c.execute(
                f"SELECT * FROM clientes WHERE nome LIKE ? ORDER BY {sql}",
                (f"%{busca.strip()}%",)
            ).fetchall()
        return [dict(r) for r in rows]

    def obter_cliente(self, cid: int) -> Optional[dict]:
        with self._con() as c:
            r = c.execute("SELECT * FROM clientes WHERE id=?", (cid,)).fetchone()
        return dict(r) if r else None

    def excluir_cliente(self, cid: int):
        with self._con() as c:
            c.execute("DELETE FROM clientes WHERE id=?", (cid,))

    def resumo(self) -> dict:
        with self._con() as c:
            r = c.execute(
                "SELECT COUNT(*) t, COALESCE(SUM(saldo),0) s, "
                "SUM(CASE WHEN saldo>0 THEN 1 ELSE 0 END) d FROM clientes"
            ).fetchone()
        return {"total": r[0], "soma": r[1], "devedores": r[2] or 0}

    def registrar_transacao(self, cid: int, tipo: str, valor: float, desc: str) -> Tuple[bool, str]:
        agora = datetime.now().isoformat(timespec="seconds")
        try:
            with self._con() as c:
                if tipo == "pagamento":
                    row = c.execute("SELECT saldo FROM clientes WHERE id=?", (cid,)).fetchone()
                    if not row:
                        return False, "Cliente não encontrado."
                    if valor > round(row[0], 2):
                        return False, f"Pagamento maior que a dívida atual (R$ {row[0]:.2f})."
                c.execute(
                    "INSERT INTO transacoes (cliente_id,tipo,valor,descricao,criado_em) VALUES (?,?,?,?,?)",
                    (cid, tipo, valor, desc.strip(), agora))
                delta = valor if tipo == "fiado" else -valor
                c.execute("UPDATE clientes SET saldo=ROUND(saldo+?,2) WHERE id=?", (delta, cid))
            return True, "ok"
        except Exception as e:
            return False, str(e)

    def quitar_total(self, cid: int) -> Tuple[bool, str]:
        with self._con() as c:
            row = c.execute("SELECT saldo FROM clientes WHERE id=?", (cid,)).fetchone()
            if not row or row[0] <= 0:
                return False, "Sem saldo devedor."
        return self.registrar_transacao(cid, "pagamento", row[0], "Quitação total")

    def historico(self, cid: int, limite=50) -> list:
        with self._con() as c:
            rows = c.execute(
                "SELECT * FROM transacoes WHERE cliente_id=? ORDER BY id DESC LIMIT ?",
                (cid, limite)
            ).fetchall()
        return [dict(r) for r in rows]
