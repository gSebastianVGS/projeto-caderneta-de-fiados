# 🌴 Caderninho de Fiados — v4 (visual completo)

Interface HTML/CSS/JS completa com coqueiros, animações e tema tropical.
Usa Chrome ou Edge já instalado no Windows como motor de renderização.

---

## ▶️ Rodar sem compilar

```bash
pip install flask pillow
python main.py
```

> Precisa de Chrome ou Edge instalado (padrão em todo Windows 10/11).

---

## 📦 Gerar executável

### Windows
```bat
build_windows.bat
```
→ `dist\FiadosCoqueiro.exe`

---

## 🪟 Como a janela abre

| Prioridade | Método | Requisito |
|---|---|---|
| 1º | **Chrome/Edge --app** | Já instalado no Windows 10/11 ✅ |
| 2º | **cefpython3** | `pip install cefpython3` (opcional) |
| 3º | **Browser padrão** | Fallback automático |

O modo `--app` abre uma janela **sem abas, sem barra de URL** — parece
um app nativo, com renderização 100% idêntica ao HTML original.

---

## 🗂️ Estrutura

```
fiados_final/
├── main.py            ← abre janela Chrome/Edge --app
├── server.py          ← API REST Flask
├── database.py        ← SQLite
├── requirements.txt
├── fiados.spec        ← PyInstaller
├── icon.ico / .png
└── templates/
    └── index.html     ← GUI HTML/CSS/JS completa
```
