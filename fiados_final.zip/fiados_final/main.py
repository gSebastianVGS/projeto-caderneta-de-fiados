"""
main.py — Caderninho de Fiados
Renderização HTML/CSS/JS completa via Chrome ou Edge instalado no Windows.

Ordem de tentativa:
  1. Chrome/Edge --app  (janela sem barra de endereço, renderização perfeita)
  2. cefpython3         (Chromium embutido — pip install cefpython3, opcional)
  3. webbrowser         (browser padrão — fallback final, mantém Flask vivo)

Nota: tkinter foi REMOVIDO intencionalmente.
      Ele puxava TCL/TK para o bundle e o UPX corrompía os arquivos .enc.
"""
import sys
import os
import time
import subprocess
import webbrowser


# ─── resolve paths dentro do .exe PyInstaller ─────────────────────────────────
def resource_path(rel: str) -> str:
    if getattr(sys, "frozen", False):
        base = sys._MEIPASS
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, rel)


sys.path.insert(0, resource_path("."))


# ─── aguarda Flask ficar pronto ────────────────────────────────────────────────
def aguardar_servidor(porta: int, timeout: float = 12.0) -> bool:
    import urllib.request
    url = f"http://127.0.0.1:{porta}/"
    t0  = time.time()
    while time.time() - t0 < timeout:
        try:
            urllib.request.urlopen(url, timeout=1)
            return True
        except Exception:
            time.sleep(0.08)
    return False


# ─── 1. Chrome / Edge em modo --app ───────────────────────────────────────────
def _achar_browser():
    """Retorna o caminho do Chrome ou Edge instalado, ou None."""
    if sys.platform == "win32":
        candidatos = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"),
        ]
        return next((p for p in candidatos if os.path.exists(p)), None)

    elif sys.platform == "darwin":
        candidatos = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        ]
        return next((p for p in candidatos if os.path.exists(p)), None)

    else:  # Linux
        for exe in ("google-chrome", "chromium-browser", "chromium", "microsoft-edge"):
            r = subprocess.run(["which", exe], capture_output=True, text=True)
            if r.returncode == 0:
                return r.stdout.strip()
        return None


def abrir_app_browser(url: str) -> bool:
    """Abre Chrome/Edge em modo --app: janela limpa sem abas nem barra de URL."""
    browser = _achar_browser()
    if not browser:
        return False

    # Perfil isolado — não interfere no perfil pessoal do usuário
    if getattr(sys, "frozen", False):
        base = os.path.dirname(sys.executable)
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    perfil = os.path.join(base, "_perfil_fiados")

    proc = subprocess.Popen([
        browser,
        f"--app={url}",
        f"--user-data-dir={perfil}",
        "--window-size=1100,720",
        "--disable-extensions",
        "--disable-translate",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-background-mode",
        "--disable-features=TranslateUI",
    ])

    # Mantém o processo Flask vivo enquanto a janela estiver aberta
    try:
        while proc.poll() is None:
            time.sleep(0.5)
    except KeyboardInterrupt:
        pass
    finally:
        try:
            proc.terminate()
        except Exception:
            pass
    return True


# ─── 2. cefpython3 (Chromium embutido, opcional) ─────────────────────────────
def abrir_cef(url: str):
    from cefpython3 import cefpython as cef
    sys.excepthook = cef.ExceptHook
    cef.Initialize({"windowless_rendering_enabled": False})
    cef.CreateBrowserSync(
        cef.WindowInfo(), url=url,
        window_title="Caderninho de Fiados"
    )
    cef.MessageLoop()
    cef.Shutdown()


# ─── 3. Fallback: browser padrão (sem tkinter — evita erro TCL/TK) ────────────
def abrir_fallback(url: str):
    """
    Abre no browser padrão do sistema.
    Mantém o Flask vivo em loop simples — sem tkinter, sem TCL, sem erros.
    """
    print(f"[Fiados] Abrindo em: {url}")
    webbrowser.open(url)
    # Mantém o processo vivo até Ctrl+C ou fechamento do terminal
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass


# ─── MAIN ──────────────────────────────────────────────────────────────────────
def main():
    from server import iniciar

    porta = iniciar()
    url   = f"http://127.0.0.1:{porta}/"
    aguardar_servidor(porta)

    # Prioridade 1: Chrome ou Edge instalado — janela nativa perfeita
    if abrir_app_browser(url):
        return

    # Prioridade 2: Chromium embutido (cefpython3, se instalado)
    try:
        import cefpython3  # noqa
        abrir_cef(url)
        return
    except ImportError:
        pass

    # Prioridade 3: browser padrão do sistema
    abrir_fallback(url)


if __name__ == "__main__":
    main()
