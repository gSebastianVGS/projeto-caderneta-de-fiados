"""
server.py — API Flask + servidor de arquivos estáticos.
Roda em localhost em porta aleatória livre.
"""
import os, sys, threading, socket
from flask import Flask, jsonify, request, send_from_directory
from database import Database


def resource_path(rel: str) -> str:
    """Resolve paths para scripts e para executáveis PyInstaller."""
    if getattr(sys, "frozen", False):
        base = sys._MEIPASS
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, rel)


TEMPLATE_DIR = resource_path("templates")

app = Flask(__name__, template_folder=TEMPLATE_DIR)
app.config["JSON_ENSURE_ASCII"] = False
db  = Database()


# ── helpers ───────────────────────────────────────────────────────────────────

def ok(data=None):
    return jsonify({"ok": True, "data": data})

def err(msg: str):
    return jsonify({"ok": False, "msg": msg}), 400


# ── rota principal ─────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return send_from_directory(TEMPLATE_DIR, "index.html")


# ── clientes ──────────────────────────────────────────────────────────────────

@app.route("/api/clientes")
def listar():
    busca = request.args.get("busca", "")
    ordem = request.args.get("ordem", "nome")
    return ok({"clientes": db.listar_clientes(busca, ordem), "resumo": db.resumo()})


@app.route("/api/clientes", methods=["POST"])
def cadastrar():
    nome = (request.json or {}).get("nome", "").strip()
    if not nome or len(nome) < 2:
        return err("Nome inválido (mínimo 2 caracteres).")
    success, msg = db.inserir_cliente(nome)
    if not success:
        return err(msg)
    clientes = db.listar_clientes()
    novo = next((c for c in clientes if c["nome"].lower() == nome.lower()), None)
    return ok({"cliente": novo, "resumo": db.resumo()})


@app.route("/api/clientes/<int:cid>")
def obter(cid):
    c = db.obter_cliente(cid)
    if not c:
        return err("Cliente não encontrado.")
    return ok({"cliente": c, "historico": db.historico(cid)})


@app.route("/api/clientes/<int:cid>", methods=["DELETE"])
def excluir(cid):
    db.excluir_cliente(cid)
    return ok({"resumo": db.resumo()})


@app.route("/api/clientes/<int:cid>/transacao", methods=["POST"])
def transacao(cid):
    body = request.json or {}
    tipo = body.get("tipo", "fiado")
    desc = body.get("descricao", "")
    try:
        valor = float(str(body.get("valor", "0")).replace(",", "."))
        if valor <= 0:
            raise ValueError
    except ValueError:
        return err("Valor inválido.")

    if not desc:
        desc = "Fiado adicionado" if tipo == "fiado" else "Pagamento recebido"

    success, msg = db.registrar_transacao(cid, tipo, valor, desc)
    if not success:
        return err(msg)

    return ok({
        "cliente":  db.obter_cliente(cid),
        "historico": db.historico(cid),
        "resumo":   db.resumo(),
    })


@app.route("/api/clientes/<int:cid>/quitar", methods=["POST"])
def quitar(cid):
    success, msg = db.quitar_total(cid)
    if not success:
        return err(msg)
    return ok({
        "cliente":  db.obter_cliente(cid),
        "historico": db.historico(cid),
        "resumo":   db.resumo(),
    })


# ── inicialização ──────────────────────────────────────────────────────────────

def _porta_livre() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


PORTA: int = None


def iniciar() -> int:
    global PORTA
    PORTA = _porta_livre()
    t = threading.Thread(
        target=lambda: app.run(
            host="127.0.0.1",
            port=PORTA,
            debug=False,
            use_reloader=False,
            threaded=True,
        ),
        daemon=True,
    )
    t.start()
    return PORTA
