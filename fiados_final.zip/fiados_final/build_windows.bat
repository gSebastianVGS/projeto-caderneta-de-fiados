@echo off
:: build_windows.bat — Caderninho de Fiados
:: Correcoes aplicadas:
::   - UPX desativado (evita erro _tcl_data\encoding\cns11643.enc)
::   - tkinter/TCL removidos do bundle (nao sao necessarios)
::
:: Requisito: Python 3.10+ em python.org + Chrome ou Edge instalado

echo.
echo ============================================================
echo   Caderninho de Fiados — Compilando executavel
echo ============================================================
echo.

:: Atualiza pip e instala dependencias minimas
python -m pip install --upgrade pip -q
python -m pip install pyinstaller flask pillow --upgrade -q

if %errorlevel% neq 0 (
    echo.
    echo ERRO: Falha ao instalar dependencias.
    echo Verifique sua conexao com a internet e tente novamente.
    pause & exit /b 1
)

echo.
echo Compilando... isso pode levar alguns minutos.
echo.

:: Compila sem UPX para evitar corrupcao de arquivos TCL/TK
python -m PyInstaller fiados.spec --clean --noconfirm

if %errorlevel% neq 0 (
    echo.
    echo ERRO: Compilacao falhou. Veja o log acima.
    pause & exit /b 1
)

echo.
echo ============================================================
echo  SUCESSO!
echo  Executavel: dist\FiadosCoqueiro.exe
echo
echo  O banco fiados.db sera criado ao lado do .exe
echo  na primeira vez que rodar.
echo
echo  REQUISITO: Chrome ou Edge instalado no computador
echo  (ja vem em todo Windows 10 e 11 por padrao).
echo ============================================================
echo.
pause
