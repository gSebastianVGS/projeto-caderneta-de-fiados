# fiados.spec — PyInstaller sem UPX e sem tkinter/TCL
# O app usa Chrome/Edge para renderizar — tkinter não é necessário.
#
# Compilar:
#   pip install pyinstaller flask pillow
#   pyinstaller fiados.spec --clean --noconfirm

block_cipher = None

a = Analysis(
    ["main.py"],
    pathex=["."],
    binaries=[],
    datas=[
        ("templates", "templates"),
        ("icon.ico",  "."),
        ("icon.png",  "."),
    ],
    hiddenimports=[
        "flask",
        "flask.templating",
        "werkzeug",
        "werkzeug.routing",
        "werkzeug.serving",
        "werkzeug.exceptions",
        "jinja2",
        "jinja2.ext",
        "click",
        "itsdangerous",
        "sqlite3",
        "threading",
        "socket",
        "urllib.request",
        "database",
        "server",
    ],
    hookspath=[],
    runtime_hooks=[],
    excludes=[
        # bibliotecas desnecessárias
        "numpy", "pandas", "matplotlib", "scipy",
        "tkinterweb", "pywebview", "cefpython3",
        # tkinter e TCL/TK — causavam o erro _tcl_data\encoding\cns11643.enc
        "tkinter", "_tkinter", "tkinter.ttk", "tkinter.messagebox",
        "Tkinter", "tcl", "tk", "turtle", "turtledemo",
    ],
    cipher=block_cipher,
    noarchive=False,
)

# Remove explicitamente qualquer binário TCL/TK que tenha escapado
a.binaries  = [b for b in a.binaries  if not any(x in b[0].lower() for x in ("tcl", "tk", "_tkinter"))]
a.datas     = [d for d in a.datas     if not any(x in d[0].lower() for x in ("tcl", "tk", "_tcl", "_tk"))]

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name    = "FiadosCoqueiro",
    debug   = False,
    strip   = False,
    upx     = False,   # ← DESATIVADO: UPX corrompía _tcl_data\encoding\*.enc
    console = False,
    icon    = "icon.ico",
)
