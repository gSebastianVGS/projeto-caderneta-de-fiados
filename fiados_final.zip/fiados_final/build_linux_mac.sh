#!/usr/bin/env bash
# build_linux_mac.sh — Linux / macOS
set -e

echo ""
echo "====================================================="
echo "  Caderninho de Fiados — Compilando executável"
echo "====================================================="
echo ""

pip3 install pyinstaller flask tkinterweb pillow --upgrade -q

python3 -m PyInstaller fiados.spec --clean --noconfirm

echo ""
echo "====================================================="
echo " SUCESSO!  dist/FiadosCoqueiro"
echo "====================================================="
echo ""
